import * as SQLite from 'expo-sqlite';

let db = null;

export const initDB = async () => {
  db = await SQLite.openDatabaseAsync('attendx.db');

  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT DEFAULT '',
      teacher TEXT DEFAULT '',
      color TEXT DEFAULT '#7C6FF7',
      threshold INTEGER DEFAULT 75
    );

    CREATE TABLE IF NOT EXISTS timetable (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      day INTEGER NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      room TEXT DEFAULT '',
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      status TEXT NOT NULL,
      UNIQUE(subject_id, date),
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      subject_id INTEGER,
      due_date TEXT,
      priority TEXT DEFAULT 'medium',
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL
    );
  `);

  return db;
};

export const getDB = () => db;

// ─── SUBJECTS ───────────────────────────────────────────────────────────────

export const getSubjects = async () =>
  db.getAllAsync('SELECT * FROM subjects ORDER BY name');

export const addSubject = async (name, code, teacher, color, threshold = 75) => {
  const r = await db.runAsync(
    'INSERT INTO subjects (name, code, teacher, color, threshold) VALUES (?, ?, ?, ?, ?)',
    [name, code, teacher, color, threshold]
  );
  return r.lastInsertRowId;
};

export const updateSubject = async (id, name, code, teacher, color, threshold) =>
  db.runAsync(
    'UPDATE subjects SET name=?, code=?, teacher=?, color=?, threshold=? WHERE id=?',
    [name, code, teacher, color, threshold, id]
  );

export const deleteSubject = async (id) =>
  db.runAsync('DELETE FROM subjects WHERE id=?', [id]);

// ─── TIMETABLE ──────────────────────────────────────────────────────────────

export const getTimetable = async () =>
  db.getAllAsync(`
    SELECT t.*, s.name AS subject_name, s.color AS subject_color, s.code AS subject_code
    FROM timetable t JOIN subjects s ON t.subject_id = s.id
    ORDER BY t.day, t.start_time
  `);

export const getTimetableForDay = async (day) =>
  db.getAllAsync(`
    SELECT t.*, s.name AS subject_name, s.color AS subject_color, s.code AS subject_code
    FROM timetable t JOIN subjects s ON t.subject_id = s.id
    WHERE t.day = ? ORDER BY t.start_time
  `, [day]);

export const addTimetableSlot = async (subject_id, day, start_time, end_time, room = '') => {
  const r = await db.runAsync(
    'INSERT INTO timetable (subject_id, day, start_time, end_time, room) VALUES (?, ?, ?, ?, ?)',
    [subject_id, day, start_time, end_time, room]
  );
  return r.lastInsertRowId;
};

export const deleteTimetableSlot = async (id) =>
  db.runAsync('DELETE FROM timetable WHERE id=?', [id]);

// ─── ATTENDANCE ─────────────────────────────────────────────────────────────

export const getAttendanceSummary = async () =>
  db.getAllAsync(`
    SELECT
      s.id, s.name, s.code, s.color, s.threshold,
      COUNT(CASE WHEN a.status='present'            THEN 1 END) AS present,
      COUNT(CASE WHEN a.status='absent'             THEN 1 END) AS absent,
      COUNT(CASE WHEN a.status='cancelled'          THEN 1 END) AS cancelled,
      COUNT(CASE WHEN a.status IN ('present','absent') THEN 1 END) AS total
    FROM subjects s
    LEFT JOIN attendance a ON s.id = a.subject_id
    GROUP BY s.id ORDER BY s.name
  `);

export const getAttendanceForSubject = async (subject_id) =>
  db.getAllAsync(
    'SELECT * FROM attendance WHERE subject_id=? ORDER BY date DESC',
    [subject_id]
  );

export const markAttendance = async (subject_id, date, status) =>
  db.runAsync(
    'INSERT OR REPLACE INTO attendance (subject_id, date, status) VALUES (?, ?, ?)',
    [subject_id, date, status]
  );

export const deleteAttendanceEntry = async (subject_id, date) =>
  db.runAsync(
    'DELETE FROM attendance WHERE subject_id=? AND date=?',
    [subject_id, date]
  );

// ─── TASKS ──────────────────────────────────────────────────────────────────

export const getTasks = async () =>
  db.getAllAsync(`
    SELECT t.*, s.name AS subject_name, s.color AS subject_color
    FROM tasks t
    LEFT JOIN subjects s ON t.subject_id = s.id
    ORDER BY
      CASE WHEN t.status='done' THEN 1 ELSE 0 END,
      CASE WHEN t.due_date IS NULL THEN 1 ELSE 0 END,
      t.due_date,
      CASE t.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END
  `);

export const addTask = async (title, description, subject_id, due_date, priority = 'medium') => {
  const r = await db.runAsync(
    'INSERT INTO tasks (title, description, subject_id, due_date, priority) VALUES (?, ?, ?, ?, ?)',
    [title, description || '', subject_id || null, due_date || null, priority]
  );
  return r.lastInsertRowId;
};

export const toggleTask = async (id, currentStatus) => {
  const next = currentStatus === 'done' ? 'pending' : 'done';
  return db.runAsync('UPDATE tasks SET status=? WHERE id=?', [next, id]);
};

export const deleteTask = async (id) =>
  db.runAsync('DELETE FROM tasks WHERE id=?', [id]);

// ─── HELPERS ─────────────────────────────────────────────────────────────────

export const calcAttendance = (present, total, threshold = 75) => {
  const pct = total > 0 ? Math.round((present / total) * 100) : null;

  // How many more can be skipped while staying above threshold
  const canBunk = pct !== null && pct >= threshold
    ? Math.floor((present - (threshold / 100) * total) / (threshold / 100))
    : 0;

  // How many must be attended to reach threshold
  const needMore = pct !== null && pct < threshold
    ? Math.ceil(((threshold / 100) * total - present) / (1 - threshold / 100))
    : 0;

  return { pct, canBunk, needMore };
};

export const clearAllData = async () => {
  await db.execAsync(`
    DELETE FROM attendance;
    DELETE FROM tasks;
    DELETE FROM timetable;
    DELETE FROM subjects;
  `);
};
